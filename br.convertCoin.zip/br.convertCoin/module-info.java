/**
 * 
 */
/**
 * @author Pedro
 *
 */
module Teset {
	requires java.dektop;
}