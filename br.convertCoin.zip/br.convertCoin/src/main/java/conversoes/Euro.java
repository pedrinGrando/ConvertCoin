package conversoes;

public class Euro {

	private double valor;

	public Euro(double valor) {
		super();
		this.valor = valor;
	}

	public Euro() {
		super();
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}
  
}
