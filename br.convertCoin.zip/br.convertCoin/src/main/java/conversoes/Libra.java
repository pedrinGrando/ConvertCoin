package conversoes;

public class Libra {

	private double valor;

	public Libra(double valor) {
		super();
		this.valor = valor;
	}

	public Libra() {
		super();
		// TODO Auto-generated constructor stub
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}
	
	
	
}
