package conversoes;

public class Dollar {

	private double valor;

	public Dollar(double valor) {
		super();
		this.valor = valor;
	}

	public Dollar() {
		super();
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}
	

}
